/*
 *  DBSCAN Clustering
 *
 *  Created on: 2025-11-09
 *      Author: Gao
 */

#include "DSP2833x_Device.h"     // DSP2833x Headerfile Include File
#include "DSP2833x_Examples.h"   // DSP2833x Examples Include File

#include "leds.h"
#include "time.h"
#include "uart.h"
#include <stdio.h>               // Include standard input/output header file


// 100 sets of float data
const float data[100] = {
    408.3697, 408.5345, 408.5214, 408.6984, 406.1382, 406.0065, 406.0880, 406.0323, 405.9812, 406.0137,
    408.2383, 405.8577, 406.3877, 408.4540, 406.3636, 408.3104, 408.1390, 408.5070, 406.2551, 406.3087,
    406.3970, 406.4959, 408.5204, 408.4881, 406.1296, 406.1701, 408.4698, 406.1218, 408.1517, 405.6831,
    406.2685, 408.2759, 405.9430, 408.5831, 406.3180, 408.3732, 408.5651, 406.1387, 408.7453, 408.4367,
    406.0535, 408.4704, 406.0056, 406.1830, 408.5100, 406.2166, 406.3935, 406.1754, 410.9800, 406.3966,
    406.1563, 408.6460, 408.3615, 408.5069, 406.2177, 408.4611, 406.1898, 408.5961, 408.5096, 408.2293,
    408.2301, 408.1497, 406.3038, 406.0942, 408.2620, 408.7306, 406.3349, 408.3869, 405.9559, 408.2554,
    406.0623, 408.2930, 408.2370, 406.1477, 405.9241, 406.0579, 406.1581, 406.1768, 406.2531, 406.1008,
    406.2402, 406.2365, 406.4325, 406.2905, 406.2951, 406.0196, 405.9804, 406.1989, 408.5208, 406.2616,
    408.2073, 408.1923, 406.1017, 406.3420, 408.4872, 408.6681, 406.2091, 406.1025, 406.0499, 408.3213
};

// DBSCAN parameters
#define EPS 0.2                  // Neighborhood radius
#define MIN_PTS 3                // Minimum number of points in neighborhood
#define MAX_CLUSTERS 5           // Maximum number of clusters

// Global variables (minimized)
char clusters[100];  // 0:unclassified, -1:noise, 1-5:cluster ID
Uint16 cluster_count = 0;
Uint16 noise_count = 0;


void InitCpuTimer0(float freq_MHz, float period_us)
{
    EALLOW;

    // 1. Enable timer clock (CpuTimer0 clock source = system clock SYSCLKOUT)
    SysCtrlRegs.PCLKCR3.bit.CPUTIMER0ENCLK = 1;  // Enable CpuTimer0 clock

    // 2. Configure timer mode: free counting (down-counting, no reload, for timing)
    CpuTimer0Regs.TCR.bit.TSS = 1;          // Stop timer
    CpuTimer0Regs.TCR.bit.TRB = 1;          // Reload timer (load PRD value)
    CpuTimer0Regs.TCR.bit.SOFT = 1;         // Soft stop mode (doesn't stop during debug)
    CpuTimer0Regs.TCR.bit.FREE = 1;         // Free-run mode (continues counting during debug)
    CpuTimer0Regs.TCR.bit.TIE = 0;          // Disable timer interrupt (only for timing, no interrupt needed)

    // 3. Configure timer period (set PRD to maximum in free-counting mode to avoid overflow)
    CpuTimer0Regs.PRD.all = 0xFFFFFFFF;     // Maximum count period (64-bit counter, sufficient for long timing)

    // 4. Configure timer prescaler (no prescaler by default, timer clock = system clock)
    CpuTimer0Regs.TPR.bit.TDDR = 0;         // Prescaler = TDDR+1 = 1 (no prescaling)
    CpuTimer0Regs.TPRH.bit.TDDRH = 0;

    // 5. Clear counter
    CpuTimer0Regs.TIM.all = 0xFFFFFFFF;     // Counter initial value = maximum (down-counting)

    // 6. Start timer
    CpuTimer0Regs.TCR.bit.TSS = 0;          // Start counting

    EDIS;
}

void delay(void)
{
    Uint16      i;
    Uint32      j;
    for(i=0;i<32;i++)
        for (j = 0; j < 100000; j++);
}
void main()
{
    Uint32 start, end;
    float time;
    int i, j, k;
    int neighbors[100];
    int q[100], qh, qt;
    int cnt, current;

    // System initialization
    InitSysCtrl();

    EALLOW;
    asm(" MOV @0x7010, #0x0000");
    asm(" MOV @0x7014, #0x0001");
    EDIS;
    InitPieCtrl();
    IER = 0; IFR = 0;
    InitPieVectTable();

    LED_Init();
    // UART initialization
    UARTa_Init(9600);


    UARTa_SendString("DBSCAN Demo\r\n");
    UARTa_SendString("EPS=0.2, MinPts=3\r\n");


    // Initialize cluster labels
    for(i = 0; i < 100; i++) clusters[i] = 0;
    cluster_count = 0;
    noise_count = 0;

    // Start timing
    InitCpuTimer0(150.0f, 0.0f);
    start = (Uint32)CpuTimer0Regs.TIM.all;;

    LED1_TOGGLE;
    delay();


    // DBSCAN algorithm
    for(i = 0; i < 100; i++)
    {
        if(clusters[i] == 0)
        {
            // Find neighborhood
            cnt = 0;
            for(j = 0; j < 100; j++)
            {
                if(fabs(data[i] - data[j]) <= EPS)
                {
                    neighbors[cnt++] = j;
                }
            }

            if(cnt < MIN_PTS)
            {
                clusters[i] = -1;  // Noise
                noise_count++;
            }
            else
            {
                cluster_count++;
                if(cluster_count > MAX_CLUSTERS)
                {
                    clusters[i] = -1;
                    noise_count++;
                    continue;
                }

                // Expand cluster (use array to simulate queue)
                qh = 0; qt = 0;
                clusters[i] = cluster_count;

                // Add neighborhood points to queue
                for(j = 0; j < cnt; j++)
                {
                    q[qt++] = neighbors[j];
                }

                // Process queue
                while(qh < qt)
                {
                    current = q[qh++];

                    if(clusters[current] == 0)
                    {
                        // Find new neighborhood
                        int new_cnt = 0;
                        int new_neighbors[100];

                        for(k = 0; k < 100; k++)
                        {
                            if(fabs(data[current] - data[k]) <= EPS)
                            {
                                new_neighbors[new_cnt++] = k;
                            }
                        }

                        if(new_cnt >= MIN_PTS)
                        {
                            // Add to queue
                            for(k = 0; k < new_cnt; k++)
                            {
                                int exists = 0;
                                for(j = qh; j < qt; j++)
                                {
                                    if(q[j] == new_neighbors[k])
                                    {
                                        exists = 1;
                                        break;
                                    }
                                }
                                if(!exists) q[qt++] = new_neighbors[k];
                            }
                        }

                        clusters[current] = cluster_count;
                    }
                    else if(clusters[current] == -1)
                    {
                        clusters[current] = cluster_count;
                        noise_count--;
                    }
                }
            }
        }
    }

    // End timing
    end = (Uint32)CpuTimer0Regs.TIM.all;
    time =  (0xFFFFFFFF - end + start) / 150000.0f;
    LED2_TOGGLE;
    delay();

    // Output results
    UARTa_SendString("\r\nResults:\r\n");
    UARTa_SendString("Clusters: ");
    UARTa_SendInt(cluster_count);
    UARTa_SendString(", Noise: ");
    UARTa_SendInt(noise_count);
    UARTa_SendString("\r\n");

    // Output each cluster
    for(i = 1; i <= cluster_count; i++)
    {
        UARTa_SendString("Cluster ");
        UARTa_SendInt(i);
        UARTa_SendString(": ");

        cnt = 0;
        for(j = 0; j < 100; j++)
        {
            if(clusters[j] == i)
            {
                if(cnt > 0&&cnt % 8 != 0) UARTa_SendString(", ");
                UARTa_SendFloat(data[j] );  // Display original value
                cnt++;
                if(cnt % 8 == 0) UARTa_SendString(", \r\n         ");
            }
        }
        UARTa_SendString("\r\n");
    }

    // Output noise points
    if(noise_count > 0)
    {
        UARTa_SendString("Noise: ");
        cnt = 0;
        for(j = 0; j < 100; j++)
        {
            if(clusters[j] == -1)
            {
                if(cnt > 0) UARTa_SendString(", ");
                UARTa_SendFloat(data[j]);
                cnt++;
            }
        }
        UARTa_SendString("\r\n");
    }

    // Output time
    UARTa_SendString("Time: ");
    UARTa_SendFloat((time));

    UARTa_SendString("us\r\n");
    UARTa_SendString("Calculate Done!\r\n");


    while(1);
}
