/*
 * uart.c
 *
 *  Created on: 2025-11-09
 *      Author: Gao
 */

#include "uart.h"


static char uart_buf[32];  // Stores formatted integer/float strings

void UARTa_Init(Uint32 baud)
{
    unsigned char scihbaud=0;
    unsigned char scilbaud=0;
    Uint16 scibaud=0;

    scibaud=37500000/(8*baud)-1;
    scihbaud=scibaud>>8;
    scilbaud=scibaud&0xff;

    EALLOW;
    SysCtrlRegs.PCLKCR0.bit.SCIAENCLK = 1;   // Enable SCI-A clock
    EDIS;

    InitSciaGpio();  // Initialize SCI pins (GPIO28=RX, GPIO29=TX)

    // Initialize SCI FIFO
    SciaRegs.SCIFFTX.all=0xE040;
    SciaRegs.SCIFFRX.all=0x204f;
    SciaRegs.SCIFFCT.all=0x0;

    // SCI configuration: 1 stop bit, no parity, 8 data bits, asynchronous mode
    SciaRegs.SCICCR.all =0x0007;
    // Enable TX/RX, disable sleep mode and error interrupts
    SciaRegs.SCICTL1.all =0x0003;
    // Enable TX/RX interrupts
    SciaRegs.SCICTL2.all =0x0003;
    SciaRegs.SCICTL2.bit.TXINTENA =1;
    SciaRegs.SCICTL2.bit.RXBKINTENA =1;
    // Configure baud rate registers
    SciaRegs.SCIHBAUD    =scihbaud;
    SciaRegs.SCILBAUD    =scilbaud;
    // Release SCI reset and enable peripheral
    SciaRegs.SCICTL1.all =0x0023;
}

// Send a single byte
void UARTa_SendByte(int a)
{
    while (SciaRegs.SCIFFTX.bit.TXFFST != 0);  // Wait until transmit FIFO is empty
    SciaRegs.SCITXBUF=a;                      // Write to transmit buffer
}

// Send a string
void UARTa_SendString(char * msg)
{
    int i=0;
    while(msg[i] != '\0')  // Loop until end of string terminator
    {
        UARTa_SendByte(msg[i]);
        i++;
    }
}

// Receive a single byte (blocking mode, waits until data is received)
int UARTa_RecvByte(void)
{
    while(SciaRegs.SCIFFRX.bit.RXFFST == 0);  // Wait until receive FIFO has data
    return SciaRegs.SCIRXBUF.all;             // Read received data
}

// Manually format integer (replaces sprintf, no library dependency)
static void IntToStr(int num, char *buf)
{
    int i = 0, j = 0, sign = 1;
    char temp[16];  // Temporarily store reversed number

    // Handle negative sign
    if (num < 0)
    {
        sign = -1;
        num = -num;
        buf[j++] = '-';
    }
    // Handle special case for 0
    else if (num == 0)
    {
        buf[j++] = '0';
        buf[j] = '\0';
        return;
    }

    // Convert number to characters (stored in reverse)
    while (num > 0)
    {
        temp[i++] = (num % 10) + '0';
        num /= 10;
    }

    // Reverse character array to get correct order
    while (i > 0)
    {
        buf[j++] = temp[--i];
    }
    buf[j] = '\0';  // String terminator
}


static void FloatToStr(float num, char *buf)
{
    int i = 0, sign = 1;
    int integer_part;  // Integer part
    int decimal_part;  // Decimal part (retains 4 digits, multiplied by 10000)

    // Handle negative sign
    if (num < 0.0f)
    {
        sign = -1;
        num = -num;
        buf[i++] = '-';
    }

    // Separate integer and decimal parts
    integer_part = (int)num;
    decimal_part = (int)((num - (float)integer_part) * 10000.0f + 0.5f);  // +0.5f for rounding

    // Format integer part
    IntToStr(integer_part, &buf[i]);
    while (buf[i] != '\0') i++;  // Move to end of integer part

    // Add decimal point
    buf[i++] = '.';

    // Format decimal part (ensure 4 digits, pad with 0 if insufficient)
    if (decimal_part < 10)
    {
        buf[i++] = '0';
        buf[i++] = '0';
        buf[i++] = '0';
        buf[i++] = decimal_part + '0';
    }
    else if (decimal_part < 100)
    {
        buf[i++] = '0';
        buf[i++] = '0';
        buf[i++] = (decimal_part / 10) + '0';
        buf[i++] = (decimal_part % 10) + '0';
    }
    else if (decimal_part < 1000)
    {
        buf[i++] = '0';
        buf[i++] = (decimal_part / 100) + '0';
        buf[i++] = ((decimal_part / 10) % 10) + '0';
        buf[i++] = (decimal_part % 10) + '0';
    }
    else
    {
        buf[i++] = (decimal_part / 1000) + '0';
        buf[i++] = ((decimal_part / 100) % 10) + '0';
        buf[i++] = ((decimal_part / 10) % 10) + '0';
        buf[i++] = (decimal_part % 10) + '0';
    }

    buf[i] = '\0';  // String terminator
}

// Send an integer
void UARTa_SendInt(int num)
{
    IntToStr(num, uart_buf);  // Manually format
    UARTa_SendString(uart_buf);
}

// Send a float (retains 4 decimal places)
void UARTa_SendFloat(float num)
{
    FloatToStr(num, uart_buf);  // Manually format
    UARTa_SendString(uart_buf);
}

// Receive an integer (blocking mode, supports positive/negative, ends with carriage return)
int UARTa_RecvInt(void)
{
    int i = 0, sign = 1, num = 0;
    char ch;

    // Skip non-numeric characters (except minus sign '-')
    while(1)
    {
        ch = UARTa_RecvByte();
        if (ch == '-' || (ch >= '0' && ch <= '9'))
            break;
    }

    // Handle negative sign
    if (ch == '-')
    {
        sign = -1;
        ch = UARTa_RecvByte();  // Read first digit after minus sign
    }

    // Read numeric characters and convert to integer
    while (ch >= '0' && ch <= '9')
    {
        num = num * 10 + (ch - '0');
        ch = UARTa_RecvByte();
        if (ch == '\r' || ch == '\n')  // End with carriage return/line feed
            break;
    }

    return num * sign;
}

// Receive a float
float UARTa_RecvFloat(void)
{
    int i = 0, sign = 1, integer_part = 0;
    float decimal_part = 0.0f, divisor = 10.0f;
    char ch;

    // Skip non-numeric characters (except minus sign '-')
    while(1)
    {
        ch = UARTa_RecvByte();
        if (ch == '-' || (ch >= '0' && ch <= '9'))
            break;
    }

    // Handle negative sign
    if (ch == '-')
    {
        sign = -1;
        ch = UARTa_RecvByte();
    }

    // Read integer part
    while (ch >= '0' && ch <= '9')
    {
        integer_part = integer_part * 10 + (ch - '0');
        ch = UARTa_RecvByte();
        if (ch == '.' || ch == '\r' || ch == '\n')
            break;
    }

    // Read decimal part (if there is a decimal point)
    if (ch == '.')
    {
        ch = UARTa_RecvByte();
        while (ch >= '0' && ch <= '9')
        {
            decimal_part += (ch - '0') / divisor;
            divisor *= 10.0f;
            ch = UARTa_RecvByte();
            if (ch == '\r' || ch == '\n')
                break;
        }
    }

    return (integer_part + decimal_part) * sign;
}
